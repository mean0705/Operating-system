#include <iostream>
#include <ctime>
#include <cstdlib>
#include<fstream>
using namespace std;

int rand31(){
    // RAND31_MAX = 2147483647
    return ( (rand() << 16) | (rand() << 1) | (rand() & 1) );
}

int main() {

    
    unsigned before = clock();
    srand(time(NULL));
    static long numbers[1000000];
        char filename[]="text.txt";
    fstream fp;
    fp.open(filename, ios::out);//�}���ɮ�
    if(!fp){//�p�G�}���ɮץ��ѡAfp��0�F���\�Afp���D0
        cout<<"Fail to open file: "<<filename<<endl;
    }
    cout<<"File Descriptor: "<<fp<<endl;
    for (int i = 0; i < 1000000; i++)
        numbers[i] = (rand31() % 1000000)+1;
    for (int i = 0; i < 1000000; i++)
        fp<<numbers[i]<<" ";//�g�J�r��
         cout<<clock() - before<<endl;
    fp.close();//�����ɮ�
    system("pause");
    return EXIT_SUCCESS;
    return 0;
}
